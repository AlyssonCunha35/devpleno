import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Generos = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get('/api/genres').then((res) => {
      setData(res.data);
    });
  }, []);
  console.log(data);
  return (
    <div>
      <h1>Generos</h1>
      <table className="table table-dark">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Ações</th>
          </tr>
        </thead>
        <tbody>
          {[data].map((d) => (
            <tr key={d.id}>
              <th scope="row">{d.id}</th>
              <td>{d.name}</td>
              <td></td>
            </tr>
          ))}
        </tbody>
      </table>
      <pre>{JSON.stringify(data)}</pre>
    </div>
  );
};

export default Generos;
